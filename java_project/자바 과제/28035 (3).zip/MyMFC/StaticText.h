#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include "Misc.h"
#include "Component.h"
using namespace std;

class Frame;
class StaticText : public Component {
public:
	StaticText(string title);
	void draw(HDC hdc) override;
	void addActionListener(ActionListener* al) override;
};