#include "Misc.h"

MPoint::MPoint(int x, int y) : x_(x), y_(y) {}

MPoint::MPoint() : x_(0), y_(0) {}

MEvent::MEvent(UINT msg, WPARAM wParam, LPARAM lParam) :
	msg_(msg), wParam_(wParam), lParam_(lParam), button_(0)
{
	//  Nothing to do here.
}

bool MEvent::isLButtonDownEvent() {
	return msg_ == WM_LBUTTONDOWN;
}
bool MEvent::isLButtonUpEvent() {
	return msg_ == WM_LBUTTONUP;
}
bool MEvent::isRButtonDownEvent() {
	return msg_ == WM_RBUTTONDOWN;
}
bool MEvent::isRButtonUpEvent() {
	return msg_ == WM_RBUTTONUP;
}

//
bool MEvent::isCtrlKeyDown() { // ctrlŰ�� ����ä�� �߻��� event����
	return wParam_ & MK_CONTROL;
}
bool MEvent::isShiftKeyDown() { // shiftŰ�� ����ä�� �߻��� event����
	return wParam_ & MK_SHIFT;
}
int MEvent::getX() {
	return LOWORD(lParam_);
}
int MEvent::getY() {
	return HIWORD(lParam_);
}
MPoint MEvent::getPoint() {
	return MPoint(LOWORD(lParam_), HIWORD(lParam_));
}

MEvent MEvent::addComponent(Component* c) { //��ư üũ�ڽ� ����
	button_ = c;
	return *this;
}

Component* MEvent::getComponent() {
	return button_;
}






