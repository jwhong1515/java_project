#pragma once
#include <Windows.h>
#include "Button.h"

class LineButton : public Button {
public:
	LineButton(HDC hdc, int x1, int y1, int x2, int y2);
	void draw();
	bool onClick(int x, int y);
};
