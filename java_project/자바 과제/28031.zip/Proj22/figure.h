#pragma once
#include <Windows.h>
class Figure{
public:
	Figure(int x1, int y1, int x2, int y2);
	virtual void draw(HDC hdc) = 0;
protected:
	int x1_, y1_, x2_, y2_;
};




