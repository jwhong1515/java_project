#include "RectButton.h"

RectButton::RectButton(HDC hdc, int x1, int y1, int x2, int y2) : Button(hdc, x1, y1, x2, y2) {}

void RectButton::draw() {
	Rectangle(hDC_, x1_, y1_, x2_, y2_);
}

bool RectButton::onClick(int x, int y) {
	if (x1_ <= x && x <= x2_ && y1_ <= y && y <= y2_) {
		return true;
	}
	return false;
}
