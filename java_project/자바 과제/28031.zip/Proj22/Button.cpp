#include "Button.h"
#include "frame.h"
using namespace std;

Button::Button(string title): title_(title) {
	width_ = 70; height_ = 25;
}
void Button::draw(HDC hdc) {
	Rectangle(hdc, x_, y_, x_ + width_, y_ + height_);
	TextOutA(hdc, x_ + 5, y_ + 4, title_.c_str(), title_.length());
}
void Button::setBounds(int x, int y, int width, int height) {
	x_ = x; y_ = y; width_ = width; height_ = height;
}
bool Button::inside(MPoint p) {
	return inside(p.x_, p.y_);
}
bool Button::inside(int x, int y) {
	return x_ < x&& x < x_ + width_ && y_ < y&& y < y_ + height_;
}
void Button::setFrame(Frame* f) {
	frame_ = f;
}
void Button::onClick(MEvent e) {
	OutputDebugStringA("clicked\n");
	frame_->setShape(this);
}
const char* Button::getTitle() {
	return title_.c_str();
}