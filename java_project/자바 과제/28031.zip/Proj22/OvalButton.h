#pragma once
#include <Windows.h>
#include "Button.h"

class OvalButton: public Button{
public:
	OvalButton(HDC hdc, int x1, int y1, int x2, int y2);
	void draw();
	bool onClick(int x, int y);
};

