#pragma once
#include <string>
#include <Windows.h>
#include "Misc.h"
using namespace std;

class Frame;
class Button{
public:
	Button(string title);
	void draw(HDC hdc);
	void setBounds(int x, int y, int width, int height);
	bool inside(MPoint p);
	bool inside(int x, int y);
	void setFrame(Frame* f);
	virtual void onClick(MEvent e);
	const char* getTitle();

protected:
	int x_, y_, width_, height_;
	string title_;
	Frame* frame_ = nullptr;
};

