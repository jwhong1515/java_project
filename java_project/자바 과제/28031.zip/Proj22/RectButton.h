#pragma once
#include <Windows.h>
#include "Button.h"

class RectButton: public Button {
public:
	RectButton(HDC hdc, int x1, int y1, int x2, int y2);
	void draw();
	bool onClick(int x, int y);
};

