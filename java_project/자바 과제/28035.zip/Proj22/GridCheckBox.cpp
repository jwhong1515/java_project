#include "GridCheckBox.h"
#include "PaintFrame.h"
using namespace std;

GridCheckBox::GridCheckBox(string title) : CheckBox(title) {

}

void GridCheckBox::actionPerformed(MEvent e) {
	CheckBox::actionPerformed(e);
	OutputDebugStringA(title_.c_str());
	((PaintFrame*)frame_)->setGrid(command_);
}