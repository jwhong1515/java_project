#include "PaintButton.h"
#include "PaintFrame.h"
using namespace std;

PaintButton::PaintButton(string title) : Button(title) {

}

//����
void PaintButton::actionPerformed(MEvent e) {
	OutputDebugStringA(title_.c_str());
	((PaintFrame*)frame_)->setFigType(command_);
}

