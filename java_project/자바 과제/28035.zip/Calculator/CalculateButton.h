#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include "Misc.h"
#include "Button.h"
using namespace std;

class CalculateButton : public Button {
public:
	CalculateButton(string title);

	//����
	void actionPerformed(MEvent e) override;

};