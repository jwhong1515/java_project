#include "CalculateButton.h"
#include "CalculateFrame.h"
using namespace std;

CalculateButton::CalculateButton(string title) : Button(title) {

}

//����
void CalculateButton::actionPerformed(MEvent e) {
	OutputDebugStringA(title_.c_str());
	((CalculateFrame*)frame_)->setFigType(command_);
}