package mylib;

import java.awt.event.ActionEvent;

public interface KActionListener{
	public void actionPerformed(ActionEvent e) ;
}
