#pragma once
#include "Misc.h"

class MEvent;
class ActionEvent;
class Component;
class Frame;
class ActionListener {
public:
	ActionListener(Frame* f);
	virtual void actionPerformed(MEvent e);
	virtual void actionPerformed(ActionEvent e);
	Frame* frame_;
};

