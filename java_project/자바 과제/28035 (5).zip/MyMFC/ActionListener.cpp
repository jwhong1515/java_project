#include "ActionListener.h"

ActionListener::ActionListener(Frame* f) {
	frame_ = f;
}

void ActionListener::actionPerformed(MEvent e) {
	frame_->actionPerformed(e);
}

void ActionListener::actionPerformed(ActionEvent e) {
	frame_->actionPerformed(e);
}