#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include "Misc.h"
#include "CheckBox.h"
using namespace std;

class GridCheckBox : public CheckBox {
public:
	GridCheckBox(string title);

	
	void onClick(MEvent e) override;
};

