#include "GridCheckBox.h"
#include "PaintFrame.h"
using namespace std;

GridCheckBox::GridCheckBox(string title) : CheckBox(title) {

}

void GridCheckBox::onClick(MEvent e) {
	CheckBox::onClick(e);
	OutputDebugStringA(title_.c_str());
	((PaintFrame*)frame_)->setGrid(command_);
}