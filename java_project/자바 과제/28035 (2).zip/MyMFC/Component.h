#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include "Misc.h"
#include "ActionListener.h"
using namespace std;

class Frame;
class Component : public ActionListener{
public:
	Component(string title);
	virtual void draw(HDC hdc);
	virtual void setBounds(int x, int y, int width, int height);
	virtual bool inside(MPoint p);
	virtual bool inside(int x, int y);
	void setFrame(Frame* f);
	const char* getTitle();

	void actionPerformed(MEvent e) override;
protected:
	int x_, y_, width_, height_;
	string title_;
	Frame* frame_ = nullptr;
};

