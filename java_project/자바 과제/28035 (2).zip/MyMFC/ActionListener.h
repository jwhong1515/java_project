#pragma once
#include "Misc.h"
class ActionListener {
public:
	virtual void actionPerformed(MEvent e) = 0;
};

