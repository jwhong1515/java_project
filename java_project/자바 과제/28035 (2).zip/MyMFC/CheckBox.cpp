#include "CheckBox.h"
#include "Frame.h"
using namespace std;

CheckBox::CheckBox(string title) : Component(title), command_(0) {

}

void CheckBox::draw(HDC hdc) { // ���� �� �ǵ�� �ؽ�Ʈ�� �ٲ� ���̴�.
	Component::draw(hdc); //Rectangle(hdc, x_, y_, x_ + width_, y_ + height_);
	string text;
	if (command_) {
		text = "[V]" + title_;
	}
	else {
		text = "[  ]" + title_;
	}

	TextOutA(hdc, x_ + 5, y_ + 4, text.c_str(), text.length());
}

//����
void CheckBox::actionPerformed(MEvent e) {
	command_ = 1 - command_;
	draw(frame_->getDC());
}

void CheckBox::setCommand(int t) {
	command_ = t;
}