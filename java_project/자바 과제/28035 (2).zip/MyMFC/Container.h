#pragma once
#include <iostream>
#include "Misc.h"
#include "MyList.h"
#include "Component.h"

class Container : public Component{
public:
	Container(string title);
	virtual void add(Component* c);
	
	//void actionPerformed(MEvent e) override;
	
protected:
	//�������� ����
	MyList<Component*> myComponentList;
};

