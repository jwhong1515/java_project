#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include "Misc.h"
#include "Button.h"
using namespace std;

class Frame;
class PaintButton : public Button {
public:
	PaintButton(string title);

	//����
	void onClick(MEvent e) override;

};

