#include "AbstractButton.h"
using namespace std;

AbstractButton::AbstractButton(string title) : Component(title), command_(0) {

}

void AbstractButton::draw(HDC hdc) {
	Component::draw(hdc); //Rectangle(hdc, x_, y_, x_ + width_, y_ + height_);
}

void AbstractButton::onClick(MEvent e) {
	if (!listeners_.isEmpty()) {
		MyList<ActionListener*>::iterator ali;
		for (ali = listeners_.begin(); ali != listeners_.end(); ali++) {
			(*ali)->actionPerformed(e.addAbstractButton(this));
		}
	}
}

void AbstractButton::setCommand(int t) {
	command_ = t;
}
int AbstractButton::getCommand() {
	return command_;
}