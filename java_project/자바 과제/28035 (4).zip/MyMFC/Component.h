#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include "Misc.h"
#include "MyList.h"
#include "ActionListener.h" //�־�� �Ѵ�.
using namespace std;

class MEvent;
class MPoint;
class Frame;
class ActionListener;
class Component {
public:
	Component(string title);
	virtual void draw(HDC hdc);
	virtual void setBounds(int x, int y, int width, int height);
	virtual bool inside(MPoint p);
	virtual bool inside(int x, int y);
	const char* getTitle();

	virtual void onClick(MEvent e);
	virtual void addActionListener(ActionListener* al);

protected:
	int x_, y_, width_, height_;
	string title_;
	Frame* frame_ = nullptr;

	//component�� actionlistener�� ��� list �־�� �Ѵ�.(���̴� �� ��ưŬ�������� ����)
	MyList<ActionListener*> listeners_;
	int command_;
};

