#pragma once
#include "Misc.h"

class MEvent;
class Component;
class Frame;
class ActionListener {
public:
	ActionListener(Frame* f);
	virtual void actionPerformed(MEvent e) = 0;
	Frame* frame_;
};

