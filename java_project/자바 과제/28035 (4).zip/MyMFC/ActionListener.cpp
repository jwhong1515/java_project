#include "ActionListener.h"

ActionListener::ActionListener(Frame* f) {
	frame_ = f;
}