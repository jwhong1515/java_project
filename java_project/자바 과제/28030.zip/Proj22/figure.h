#pragma once
#include <Windows.h>
class Figure{
public:
	Figure(HDC hdc, int x1, int y1, int x2, int y2);
	virtual void draw() = 0;
protected:
	HDC hDC_;
	int x1_, y1_, x2_, y2_;
};




