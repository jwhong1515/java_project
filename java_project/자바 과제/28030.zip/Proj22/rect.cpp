#include "rect.h"

Rect::Rect(HDC hdc, int x1, int y1, int x2, int y2) : Figure(hdc, x1, y1, x2, y2) {}

void Rect::draw() {
	Rectangle(hDC_, x1_, y1_, x2_, y2_);
}

