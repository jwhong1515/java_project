#include "figure.h"

Figure::Figure(HDC hdc, int x1, int y1, int x2, int y2) : hDC_(hdc), x1_(x1), y1_(y1), x2_(x2), y2_(y2) {}