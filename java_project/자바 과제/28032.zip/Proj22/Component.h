#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include "Misc.h"
using namespace std;

class Frame;
class Component {
public:
	Component(string title);
	virtual void draw(HDC hdc);
	virtual void setBounds(int x, int y, int width, int height);
	virtual bool inside(MPoint p);
	virtual bool inside(int x, int y);
	virtual void onClick(MEvent e);
	void setFrame(Frame* f);
	void setCommand(int t); //�Լ���ü�� ���̺귯���� �δ� �� ���� �� �ϴ�
	const char* getTitle();
	/*
	string getTextString();
	void Text(string s);
	*/
protected:
	int x_, y_, width_, height_;
	string title_;
	Frame* frame_ = nullptr;

	int command_;
};

