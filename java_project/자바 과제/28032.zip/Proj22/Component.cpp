#include "Component.h"
#include "frame.h"
using namespace std;

Component::Component(string title) : title_(title), x_(0), y_(0), width_(70), height_(25), command_(0) {
}
void Component::draw(HDC hdc) {

}
void Component::setBounds(int x, int y, int width, int height) {
	x_ = x; y_ = y; width_ = width; height_ = height;
}
bool Component::inside(MPoint p) {
	return inside(p.x_, p.y_);
}
bool Component::inside(int x, int y) {
	return x_ < x&& x < x_ + width_ && y_ < y&& y < y_ + height_;
}
void Component::setFrame(Frame* f) {
	frame_ = f;
}
void Component::onClick(MEvent e) {

}
const char* Component::getTitle() {
	return title_.c_str();
}

void Component::setCommand(int t) {
	command_ = t;
}
