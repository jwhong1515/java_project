#include "painterframe.h"
#include "rect.h"
#include "oval.h"
#include "line.h"
#include "MButton.h" //����Ŭ���� include�ϸ� ����class�� include��
#include "MCheckBox.h"
#include <iostream>


PainterFrame::PainterFrame() :PainterFrame(L"", 800, 600) {
	// ���� ������ �ʰ� ����.
}

PainterFrame::PainterFrame(std::wstring title, int width, int height): Frame(title, width, height) {

}

bool PainterFrame::eventHandler(MEvent e) {

	// TODO: ���⿡ ���� �ڵ� �߰�.
	OutputDebugString(L"Event\n");
	std::cout << L"Event\n" << std::endl;  // ����� cmd â���� ���

	Frame::eventHandler(e);
	// �̺�Ʈ�� ������ �ľ��ؼ� �簢�� �׸��⸦ ���⼭ ���ش�.
	if (e.isLButtonDownEvent() || e.isRButtonDownEvent()) {
		start_ = e.getPoint();
		OutputDebugString(L"Down\n");
	}
	else if (e.isLButtonUpEvent()) {
		end_ = e.getPoint();
		OutputDebugString(L"Up\n");

		if (grid) {
				if (figType == FIG_RECT) {
					myFigureList.push_back(new Rect((start_.x_ + 10) / 20 * 20, (start_.y_ + 10) / 20 * 20, end_.x_, end_.y_));
				}
				else if (figType == FIG_OVAL) {
					myFigureList.push_back(new Oval((start_.x_ + 10) / 20 * 20, (start_.y_ + 10) / 20 * 20, end_.x_, end_.y_));
				}
				else if (figType == FIG_LINE) {
					myFigureList.push_back(new Line((start_.x_ + 10) / 20 * 20, (start_.y_ + 10) / 20 * 20, end_.x_, end_.y_));
				}
		}
		else {
			if (figType == FIG_RECT) {
				myFigureList.push_back(new Rect(start_.x_, start_.y_, end_.x_, end_.y_));
			}
			else if (figType == FIG_OVAL) {
				myFigureList.push_back(new Oval(start_.x_, start_.y_, end_.x_, end_.y_));
			}
			else if (figType == FIG_LINE) {
				myFigureList.push_back(new Line(start_.x_, start_.y_, end_.x_, end_.y_));
			}
		}

		invalidate();
	}
	else if (e.isRButtonUpEvent()) {
		end_ = e.getPoint();
		OutputDebugString(L"Up\n");

		invalidate();
	}

	return false;
}

void PainterFrame::repaint() {
	// �׷����� ��� ���� ���⿡. 
	Frame::repaint();
	//����
	vector<Figure*>::iterator fi;
	for (fi = myFigureList.begin(); fi != myFigureList.end(); fi++) {
		(*fi)->draw(hDC_);
	}
}

void PainterFrame::initialize() {
	Component* btnRect = new MButton("�簢��");
	Component* btnOval = new MButton("Ÿ��");
	Component* btnLine = new MButton("����");
	Component* btnGrid = new MCheckBox("[  ] �׸���");
	add(btnRect);
	add(btnOval);
	add(btnLine);
	add(btnGrid);
	btnRect->setCommand(FIG_RECT);
	btnOval->setCommand(FIG_OVAL);
	btnLine->setCommand(FIG_LINE);
	btnGrid->setCommand(SET_GRID);
	btnRect->setBounds(10, 10, 75, 25);
	btnOval->setBounds(100, 10, 75, 25);
	btnLine->setBounds(190, 10, 75, 25);
	btnGrid->setBounds(280, 10, 75, 25);
}

void PainterFrame::setFigType(int t) {
	figType = t;
}

void PainterFrame::setGrid(int t) {
	grid = t;
}

