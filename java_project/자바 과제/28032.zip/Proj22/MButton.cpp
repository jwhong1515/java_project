#include "MButton.h"
#include "PainterFrame.h"
using namespace std;

MButton::MButton(string title) : Component(title) {

}

void MButton::draw(HDC hdc) {
	Rectangle(hdc, x_, y_, x_ + width_, y_ + height_);
	TextOutA(hdc, x_ + 5, y_ + 4, title_.c_str(), title_.length());
}

//����
void MButton::onClick(MEvent e) {
	OutputDebugStringA(title_.c_str());
	((PainterFrame*)frame_)->setFigType(command_);
}


