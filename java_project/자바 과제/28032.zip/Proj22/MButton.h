#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include "Misc.h"
#include "Component.h"
using namespace std;

class Frame;
class MButton: public Component{
public:
	MButton(string title);
	void draw(HDC hdc) override;

	//����
	void onClick(MEvent e) override;

};

